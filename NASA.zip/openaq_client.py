"""
OpenAQ Client for fetching ground truth air quality data
"""

import requests
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import os

class OpenAQClient:
    def __init__(self):
        self.base_url = "https://api.openaq.org/v3"
        self.cache = {}
        self.cache_duration = 300  # 5 minutes
        self.api_key = os.getenv('OPENAQ_API_KEY', '')  # Get API key from environment
        
    def get_measurements(self, lat: float, lon: float, time: Optional[str] = None) -> Dict:
        """
        Get air quality measurements from OpenAQ for a specific location
        
        Args:
            lat: Latitude
            lon: Longitude
            time: Optional timestamp (ISO format)
            
        Returns:
            Dictionary containing air quality measurements
        """
        # Check cache first
        cache_key = f"{lat}_{lon}_{time}"
        if cache_key in self.cache:
            cached_data, cached_time = self.cache[cache_key]
            if datetime.now() - cached_time < timedelta(seconds=self.cache_duration):
                return cached_data
        
        try:
            # Use the current OpenAQ API v2 format with authentication
            headers = {
                'Accept': 'application/json',
                'User-Agent': 'TEMPO-Air-Quality-Validator/1.0'
            }
            
            # Add API key if available
            if self.api_key:
                headers['X-API-Key'] = self.api_key
            
            # Build API request with v3 parameters
            params = {
                'coordinates': f"{lat},{lon}",
                'radius': 10000,  # 10km radius
                'limit': 100,
                'order_by': 'datetime',
                'sort': 'desc'
            }
            
            if time:
                params['date_from'] = time
                params['date_to'] = time
            
            # Try the v3 API endpoint
            response = requests.get(f"{self.base_url}/measurements", 
                                  params=params, 
                                  headers=headers,
                                  timeout=10)
            
            response.raise_for_status()
            data = response.json()
            
            # Process and structure the data
            measurements = self._process_measurements(data.get('results', []))
            
            # Cache the result
            self.cache[cache_key] = (measurements, datetime.now())
            
            return {
                'location': {'lat': lat, 'lon': lon},
                'timestamp': time or datetime.now().isoformat(),
                'measurements': measurements,
                'source': 'OpenAQ',
                'api_status': 'live'
            }
            
        except requests.exceptions.RequestException as e:
            return {
                'error': f'OpenAQ API request failed: {str(e)}',
                'location': {'lat': lat, 'lon': lon},
                'timestamp': time or datetime.now().isoformat(),
                'source': 'OpenAQ',
                'api_status': 'error'
            }
    
    def _process_measurements(self, raw_measurements: List[Dict]) -> List[Dict]:
        """
        Process raw OpenAQ measurements into standardized format
        """
        processed = []
        
        for measurement in raw_measurements:
            processed.append({
                'parameter': measurement.get('parameter'),
                'value': measurement.get('value'),
                'unit': measurement.get('unit'),
                'datetime': measurement.get('date', {}).get('utc'),
                'location': {
                    'lat': measurement.get('coordinates', {}).get('latitude'),
                    'lon': measurement.get('coordinates', {}).get('longitude')
                },
                'country': measurement.get('country'),
                'city': measurement.get('city'),
                'location_name': measurement.get('location')
            })
        
        return processed
    
    def get_latest_measurements(self, lat: float, lon: float) -> Dict:
        """
        Get the most recent measurements for a location
        """
        return self.get_measurements(lat, lon)
    
    def get_historical_data(self, lat: float, lon: float, days: int = 7) -> Dict:
        """
        Get historical data for the past N days
        """
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        return self.get_measurements(
            lat, 
            lon, 
            start_date.isoformat()
        )
    
    def get_parameter_summary(self, measurements: List[Dict]) -> Dict:
        """
        Get summary statistics for air quality parameters
        """
        parameters = {}
        
        for measurement in measurements:
            param = measurement.get('parameter')
            value = measurement.get('value')
            
            if param and value is not None:
                if param not in parameters:
                    parameters[param] = {
                        'values': [],
                        'unit': measurement.get('unit'),
                        'count': 0
                    }
                
                parameters[param]['values'].append(value)
                parameters[param]['count'] += 1
        
        # Calculate statistics
        for param, data in parameters.items():
            values = data['values']
            data['mean'] = sum(values) / len(values)
            data['min'] = min(values)
            data['max'] = max(values)
            data['latest'] = values[0] if values else None
        
        return parameters
    
