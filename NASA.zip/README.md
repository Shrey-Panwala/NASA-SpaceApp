# TEMPO Air Quality Validator and Forecaster

A full-stack web application that integrates NASA satellite data (from the SPoRt Viewer) with ground-truth data (from OpenAQ) to validate, correct, and forecast local Air Quality Index (AQI) for the North American region.

## 🎯 Project Overview

This application fulfills the 2025 NASA Space Apps Challenge objectives by:

- **Validating** satellite air quality data against ground truth measurements
- **Correcting** satellite data using machine learning models
- **Forecasting** air quality conditions with high accuracy
- **Alerting** users when air quality exceeds safe thresholds

## 🛠 Technology Stack

| Component | Technology | Purpose |
|-----------|------------|---------|
| Backend API | Python Flask | Data processing and API endpoints |
| Data Sources | OpenAQ, SPoRt Viewer | Ground truth and satellite data |
| ML Models | Scikit-learn | Error correction and calibration |
| Frontend | React | Interactive web interface |
| Mapping | Leaflet.js | Geographic visualization |
| Data Processing | Pandas, NumPy | Analysis and manipulation |

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- Node.js 16+
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd tempo-air-quality-validator
   ```

2. **Set up Python backend**
   ```bash
   # Create virtual environment
   python -m venv venv
   
   # Activate virtual environment
   # Windows:
   venv\\Scripts\\activate
   # macOS/Linux:
   source venv/bin/activate
   
   # Install dependencies
   pip install -r requirements.txt
   ```

3. **Set up React frontend**
   ```bash
   cd frontend
   npm install
   ```

4. **Configure environment**
   ```bash
   # Copy environment template
   cp env.example .env
   
   # Edit .env with your configuration
   ```

### Running the Application

1. **Start the Flask backend**
   ```bash
   python app.py
   ```
   The API will be available at `http://localhost:5000`

2. **Start the React frontend**
   ```bash
   cd frontend
   npm start
   ```
   The web interface will be available at `http://localhost:3000`

## 📊 API Endpoints

### Core Endpoints

- `GET /api/ground_data` - Fetch ground truth data from OpenAQ
- `GET /api/satellite_data` - Fetch satellite data from SPoRt Viewer
- `GET /api/calculate_aqi` - Calculate corrected AQI using ML models
- `GET /api/forecast` - Generate air quality forecasts
- `POST /api/alerts` - Create user alerts for AQI thresholds

### Example Usage

```bash
# Get AQI for New York City
curl "http://localhost:5000/api/calculate_aqi?lat=40.7128&lon=-74.0060"

# Get 24-hour forecast
curl "http://localhost:5000/api/forecast?lat=40.7128&lon=-74.0060&hours_ahead=24"

# Create an alert
curl -X POST "http://localhost:5000/api/alerts" \
  -H "Content-Type: application/json" \
  -d '{"lat": 40.7128, "lon": -74.0060, "threshold": 100}'
```

## 🔬 Scientific Validation Process

### 1. Data Acquisition
- **Ground Data**: Real-time measurements from OpenAQ sensors
- **Satellite Data**: TEMPO satellite observations via SPoRt Viewer
- **Geographic Coverage**: North American region

### 2. Validation & Correction
- **Geo-temporal Matching**: Align satellite and ground measurements
- **Error Analysis**: Calculate bias and accuracy metrics
- **ML Correction**: Train models to reduce systematic errors
- **Quality Assessment**: Evaluate validation success

### 3. AQI Calculation
- **EPA Standards**: Follow official AQI calculation methods
- **Multi-pollutant**: PM2.5, O3, NO2, PM10
- **Health Categories**: Good, Moderate, Unhealthy, etc.

### 4. Forecasting
- **Temporal Patterns**: Diurnal and seasonal variations
- **Spatial Interpolation**: Geographic data distribution
- **Confidence Intervals**: Uncertainty quantification

## 🎨 Frontend Features

### Interactive Map
- **Click to Select**: Choose any location on the map
- **Real-time Data**: Display current air quality conditions
- **Visual Indicators**: Color-coded AQI levels

### Air Quality Dashboard
- **Current AQI**: Primary air quality index
- **Parameter Breakdown**: Individual pollutant concentrations
- **Health Recommendations**: Safety guidelines based on AQI

### Forecasting
- **24-Hour Forecast**: Hourly predictions
- **Trend Analysis**: Improving/deteriorating conditions
- **Confidence Levels**: Forecast reliability

### Alert System
- **Custom Thresholds**: Set personal AQI limits
- **Location-based**: Alerts for specific areas
- **Real-time Notifications**: Immediate updates

## 🔧 Configuration

### Environment Variables

```bash
# Flask Configuration
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-secret-key

# API Endpoints
OPENAQ_API_URL=https://api.openaq.org/v2
SPORT_VIEWER_API_URL=https://sport.gsfc.nasa.gov/api

# Caching
CACHE_DURATION_GROUND_DATA=300
CACHE_DURATION_SATELLITE_DATA=1800

# ML Models
MODEL_PATH=models/correction_models.pkl
```

### Data Sources

1. **OpenAQ**: Ground truth air quality measurements
   - Real-time and historical data
   - Global sensor network
   - Multiple pollutants (PM2.5, O3, NO2, etc.)

2. **SPoRt Viewer**: NASA satellite data
   - TEMPO instrument data
   - Geostationary coverage
   - High temporal resolution

## 📈 Machine Learning Pipeline

### Data Preparation
- **Feature Engineering**: Geographic and temporal features
- **Data Cleaning**: Outlier detection and removal
- **Normalization**: Scale features for ML models

### Model Training
- **Random Forest**: Primary correction model
- **Cross-validation**: Ensure model generalization
- **Feature Importance**: Identify key correction factors

### Model Deployment
- **Real-time Correction**: Apply models to live data
- **Performance Monitoring**: Track model accuracy
- **Continuous Learning**: Update models with new data

## 🚨 Alert System

### Alert Types
- **High AQI**: When air quality exceeds safe levels
- **User-defined**: Custom thresholds for specific locations
- **Forecast Alerts**: Predictive warnings

### Notification Methods
- **Web Interface**: Real-time dashboard updates
- **Email**: Optional email notifications
- **Visual Indicators**: Color-coded alerts

## 📊 Data Visualization

### Map Layers
- **Ground Stations**: OpenAQ sensor locations
- **Satellite Coverage**: TEMPO observation areas
- **AQI Forecasts**: Predicted air quality zones

### Charts and Graphs
- **Time Series**: Historical trends
- **Parameter Comparison**: Multi-pollutant analysis
- **Forecast Confidence**: Uncertainty visualization

## 🔍 Validation Metrics

### Accuracy Measures
- **Mean Absolute Error (MAE)**: Average prediction error
- **Root Mean Square Error (RMSE)**: Prediction variance
- **R² Score**: Model fit quality
- **Percent Error**: Relative accuracy

### Quality Categories
- **Excellent**: < 10% error
- **Good**: 10-20% error
- **Fair**: 20-30% error
- **Poor**: > 30% error

## 🛡️ Error Handling

### API Errors
- **Network Issues**: Retry mechanisms
- **Data Unavailable**: Graceful degradation
- **Rate Limiting**: Respect API limits

### User Experience
- **Loading States**: Clear progress indicators
- **Error Messages**: Helpful error descriptions
- **Fallback Data**: Default values when possible

## 🚀 Deployment

### Production Setup
1. **Environment Configuration**: Set production variables
2. **Database Setup**: Configure persistent storage
3. **Model Deployment**: Load trained ML models
4. **Monitoring**: Set up logging and alerts

### Scaling Considerations
- **Caching**: Redis for data caching
- **Load Balancing**: Multiple API instances
- **CDN**: Static asset delivery
- **Database**: PostgreSQL for production

## 📚 Documentation

### API Documentation
- **OpenAPI/Swagger**: Interactive API documentation
- **Code Examples**: Usage examples in multiple languages
- **Error Codes**: Comprehensive error reference

### User Guide
- **Getting Started**: Quick start tutorial
- **Feature Overview**: Detailed feature descriptions
- **Troubleshooting**: Common issues and solutions

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

### Code Standards
- **Python**: PEP 8 style guide
- **JavaScript**: ESLint configuration
- **Testing**: Unit and integration tests
- **Documentation**: Inline code comments

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **NASA**: For satellite data and SPoRt Viewer API
- **OpenAQ**: For ground truth air quality data
- **EPA**: For AQI calculation standards
- **OpenStreetMap**: For mapping data

## 📞 Support

For questions, issues, or contributions:
- **Issues**: GitHub Issues
- **Discussions**: GitHub Discussions
- **Email**: [Contact Information]

---

**Built for NASA Space Apps Challenge 2025** 🚀
