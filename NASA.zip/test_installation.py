#!/usr/bin/env python3
"""
Test script to verify TEMPO Air Quality Validator installation
"""

import sys
import importlib
import subprocess
from pathlib import Path

def test_python_version():
    """Test Python version compatibility"""
    print("🐍 Testing Python version...")
    if sys.version_info >= (3, 8):
        print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} is compatible")
        return True
    else:
        print(f"❌ Python {sys.version_info.major}.{sys.version_info.minor} is not compatible (requires 3.8+)")
        return False

def test_dependencies():
    """Test if all required packages are installed"""
    print("\n📦 Testing Python dependencies...")
    
    required_packages = {
        'flask': 'Flask',
        'flask_cors': 'Flask-CORS',
        'requests': 'requests',
        'pandas': 'pandas',
        'numpy': 'numpy',
        'sklearn': 'scikit-learn',
        'aqi': 'python-aqi',
        'geopy': 'geopy'
    }
    
    all_installed = True
    for package, display_name in required_packages.items():
        try:
            importlib.import_module(package)
            print(f"✅ {display_name}")
        except ImportError:
            print(f"❌ {display_name} - Not installed")
            all_installed = False
    
    return all_installed

def test_file_structure():
    """Test if all required files exist"""
    print("\n📁 Testing file structure...")
    
    required_files = [
        'app.py',
        'requirements.txt',
        'api/openaq_client.py',
        'api/sport_viewer_client.py',
        'services/data_validator.py',
        'services/aqi_calculator.py',
        'services/forecast_service.py',
        'templates/index.html',
        'frontend/package.json',
        'frontend/src/App.js'
    ]
    
    all_files_exist = True
    for file_path in required_files:
        if Path(file_path).exists():
            print(f"✅ {file_path}")
        else:
            print(f"❌ {file_path} - Missing")
            all_files_exist = False
    
    return all_files_exist

def test_api_imports():
    """Test if API modules can be imported"""
    print("\n🔌 Testing API imports...")
    
    try:
        from api.openaq_client import OpenAQClient
        print("✅ OpenAQ Client")
    except ImportError as e:
        print(f"❌ OpenAQ Client - {e}")
        return False
    
    try:
        from api.sport_viewer_client import SPoRtViewerClient
        print("✅ SPoRt Viewer Client")
    except ImportError as e:
        print(f"❌ SPoRt Viewer Client - {e}")
        return False
    
    try:
        from services.data_validator import DataValidator
        print("✅ Data Validator")
    except ImportError as e:
        print(f"❌ Data Validator - {e}")
        return False
    
    try:
        from services.aqi_calculator import AQICalculator
        print("✅ AQI Calculator")
    except ImportError as e:
        print(f"❌ AQI Calculator - {e}")
        return False
    
    try:
        from services.forecast_service import ForecastService
        print("✅ Forecast Service")
    except ImportError as e:
        print(f"❌ Forecast Service - {e}")
        return False
    
    return True

def test_node_installation():
    """Test if Node.js is installed"""
    print("\n🟢 Testing Node.js installation...")
    
    try:
        result = subprocess.run(['node', '--version'], 
                              capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            print(f"✅ Node.js {result.stdout.strip()}")
            return True
        else:
            print("❌ Node.js not working properly")
            return False
    except (subprocess.TimeoutExpired, FileNotFoundError):
        print("❌ Node.js not installed or not in PATH")
        return False

def test_frontend_dependencies():
    """Test if frontend dependencies are installed"""
    print("\n📦 Testing frontend dependencies...")
    
    frontend_path = Path('frontend')
    if not frontend_path.exists():
        print("❌ Frontend directory not found")
        return False
    
    package_json = frontend_path / 'package.json'
    if not package_json.exists():
        print("❌ package.json not found")
        return False
    
    node_modules = frontend_path / 'node_modules'
    if not node_modules.exists():
        print("⚠️  Frontend dependencies not installed")
        print("   Run: cd frontend && npm install")
        return False
    
    print("✅ Frontend dependencies installed")
    return True

def test_environment_setup():
    """Test environment configuration"""
    print("\n⚙️  Testing environment setup...")
    
    env_file = Path('.env')
    env_example = Path('env.example')
    
    if env_file.exists():
        print("✅ Environment file (.env) exists")
    elif env_example.exists():
        print("⚠️  Environment file not found, but template exists")
        print("   Copy env.example to .env and configure")
    else:
        print("❌ No environment configuration found")
        return False
    
    return True

def run_basic_functionality_test():
    """Run basic functionality tests"""
    print("\n🧪 Running basic functionality tests...")
    
    try:
        # Test OpenAQ Client
        from api.openaq_client import OpenAQClient
        openaq = OpenAQClient()
        print("✅ OpenAQ Client initialized")
        
        # Test SPoRt Viewer Client
        from api.sport_viewer_client import SPoRtViewerClient
        sport = SPoRtViewerClient()
        print("✅ SPoRt Viewer Client initialized")
        
        # Test Data Validator
        from services.data_validator import DataValidator
        validator = DataValidator()
        print("✅ Data Validator initialized")
        
        # Test AQI Calculator
        from services.aqi_calculator import AQICalculator
        aqi_calc = AQICalculator()
        print("✅ AQI Calculator initialized")
        
        # Test Forecast Service
        from services.forecast_service import ForecastService
        forecast = ForecastService()
        print("✅ Forecast Service initialized")
        
        return True
        
    except Exception as e:
        print(f"❌ Basic functionality test failed: {e}")
        return False

def main():
    """Main test function"""
    print("🧪 TEMPO Air Quality Validator - Installation Test")
    print("=" * 60)
    
    tests = [
        ("Python Version", test_python_version),
        ("Python Dependencies", test_dependencies),
        ("File Structure", test_file_structure),
        ("API Imports", test_api_imports),
        ("Node.js Installation", test_node_installation),
        ("Frontend Dependencies", test_frontend_dependencies),
        ("Environment Setup", test_environment_setup),
        ("Basic Functionality", run_basic_functionality_test)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} test failed with error: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 TEST SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed! Your installation is ready.")
        print("\n🚀 To start the application:")
        print("   1. Backend: python start_backend.py")
        print("   2. Frontend: start_frontend.bat (Windows) or ./start_frontend.sh (macOS/Linux)")
    else:
        print(f"\n⚠️  {total - passed} tests failed. Please check the issues above.")
        print("\n🔧 Common solutions:")
        print("   - Install missing dependencies: pip install -r requirements.txt")
        print("   - Install Node.js: https://nodejs.org/")
        print("   - Install frontend dependencies: cd frontend && npm install")
        print("   - Copy environment file: cp env.example .env")

if __name__ == '__main__':
    main()
