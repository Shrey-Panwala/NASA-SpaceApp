#!/usr/bin/env python3
"""
Startup script for TEMPO Air Quality Validator Backend
"""

import os
import sys
import subprocess
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        sys.exit(1)
    print(f"✅ Python version: {sys.version}")

def check_dependencies():
    """Check if required packages are installed"""
    required_packages = [
        'flask', 'flask_cors', 'requests', 'pandas', 
        'numpy', 'scikit-learn', 'python-aqi', 'geopy'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"❌ Missing packages: {', '.join(missing_packages)}")
        print("Installing missing packages...")
        subprocess.run([sys.executable, '-m', 'pip', 'install'] + missing_packages)
    else:
        print("✅ All required packages are installed")

def create_directories():
    """Create necessary directories"""
    directories = ['data', 'models', 'logs']
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
    print("✅ Directory structure created")

def setup_environment():
    """Set up environment variables"""
    env_file = Path('.env')
    if not env_file.exists():
        env_example = Path('env.example')
        if env_example.exists():
            env_file.write_text(env_example.read_text())
            print("✅ Environment file created from template")
        else:
            print("⚠️  No environment template found")

def start_flask_app():
    """Start the Flask application"""
    print("🚀 Starting TEMPO Air Quality Validator Backend...")
    print("📍 API will be available at: http://localhost:5000")
    print("📊 Health check: http://localhost:5000/")
    print("🛑 Press Ctrl+C to stop the server")
    print("-" * 50)
    
    try:
        from app import app
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\n👋 Server stopped by user")
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        sys.exit(1)

def main():
    """Main startup function"""
    print("🌍 TEMPO Air Quality Validator Backend")
    print("=" * 50)
    
    # Check system requirements
    check_python_version()
    check_dependencies()
    
    # Setup environment
    create_directories()
    setup_environment()
    
    # Start the application
    start_flask_app()

if __name__ == '__main__':
    main()
